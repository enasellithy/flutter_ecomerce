import 'package:flutter/material.dart';
import '../pages/cart.dart';

class ProductDetails extends StatefulWidget {
  final product_detail_name;
  final product_detail_new_price;
  final product_detail_old_price;
  final product_detail_picture;

  ProductDetails({
    this.product_detail_name,
    this.product_detail_new_price,
    this.product_detail_old_price,
    this.product_detail_picture
  });

  @override
  _ProductDetailsState createState() => _ProductDetailsState();
}

class _ProductDetailsState extends State<ProductDetails> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Fashapp'),
        backgroundColor: Colors.red,
        actions: [
          IconButton(
            icon: Icon(Icons.search, color: Colors.white,),
            onPressed: (){
              Navigator.of(context).push(MaterialPageRoute(builder: (context) => Cart()));
            },
          ),
          IconButton(
            icon: Icon(Icons.shopping_cart, color: Colors.white,),
            onPressed: (){
              
            },
          ),
        ],
      ),
      body: ListView(
        children: [
          Container(
            height: 300.0,
            child: GridTile(
              child: Container(
                color: Colors.white,
                child: Image.asset(widget.product_detail_picture),
              ),
              footer: Container(
                color: Colors.white,
                child: ListTile(
                  leading: Text(widget.product_detail_name, style: TextStyle(
                    fontWeight: FontWeight.bold, fontSize: 16.0,
                  ),),
                  title: Row(
                    children: [
                      Expanded(
                        child: Text("${widget.product_detail_old_price}", style: TextStyle(
                          color: Colors.grey, decoration: TextDecoration.lineThrough
                        ),),
                      ),
                      Expanded(
                        child: Text("${widget.product_detail_new_price}", style: TextStyle(
                          fontWeight: FontWeight.bold, color: Colors.red,
                        ),),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),

          /**************************************************************************************************
           * the first buttons
           *************************************************************************************************/
          Row(
            children: [
              // ============================= the size button =============================
              Expanded(
                child: MaterialButton(
                  onPressed: (){
                    showDialog(context: context,
                    builder: (context){
                      return AlertDialog(
                        title: Text("Size"),
                        content: Text("Chooes the size"),
                        actions: [
                          MaterialButton(
                            onPressed: (){},
                            child: Text("close"),
                          ),
                        ],
                      );
                    });
                  },
                  color: Colors.white,
                  textColor: Colors.grey,
                  elevation: 0.2,
                  child: Row(
                    children: [
                      Expanded(child: Text('Size'),),
                      Expanded(child: Icon(Icons.arrow_drop_down),),
                    ],
                  ),
                ),
              ),

              // ============================= the color button =============================
              Expanded(
                child: MaterialButton(
                  onPressed: (){
                    showDialog(context: context,
                    builder: (context){
                      return AlertDialog(
                        title: Text("Color"),
                        content: Text("Chooes the color"),
                        actions: [
                          MaterialButton(
                            onPressed: (){},
                            child: Text("close"),
                          ),
                        ],
                      );
                    });
                  },
                  color: Colors.white,
                  elevation: 0.2,
                  textColor: Colors.grey,
                  child: Row(
                    children: [
                      Expanded(child: Text('Color'),),
                      Expanded(child: Icon(Icons.arrow_drop_down),),
                    ],
                  ),
                ),
              ),

              // ============================= the quantity button =============================
              Expanded(
                child: MaterialButton(
                  onPressed: (){
                    showDialog(context: context,
                    builder: (context){
                      return AlertDialog(
                        title: Text("Quantity"),
                        content: Text("Chooes the size"),
                        actions: [
                          MaterialButton(
                            onPressed: (){},
                            child: Text("close"),
                          ),
                        ],
                      );
                    });
                  },
                  color: Colors.white,
                  elevation: 0.2,
                  textColor: Colors.grey,
                  child: Row(
                    children: [
                      Expanded(child: Text('Qty'),),
                      Expanded(child: Icon(Icons.arrow_drop_down),),
                    ],
                  ),
                ),
              ),
              
            ],
          ),

          /**************************************************************************************************
           * the secound buttons
           *************************************************************************************************/

           Row(
             children: [
               Expanded(
                 child: MaterialButton(
                   onPressed: (){},
                   color: Colors.red,
                   textColor: Colors.white,
                   elevation: 0.2,
                   child: Text('Buy now'),
                 ),
               ),
               IconButton(
                 icon: Icon(Icons.add_shopping_cart, color: Colors.red,),
               ),
               IconButton(
                 icon: Icon(Icons.favorite_border, color: Colors.red,),
               ),
             ],
           ),

           Divider(),

           ListTile(
             title: Text("Product details"),
             subtitle: Text("It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for 'lorem ipsum' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like)."),
           ),

           Divider(),

           Row(
             children: [
               Padding(
                 padding: EdgeInsets.fromLTRB(12.0, 5.0, 5.0, 5.0),
                 child: Text("product name", style: TextStyle(color: Colors.grey,),),
               ),
               Padding(
                 padding: EdgeInsets.all(5.0),
                 child: Text(widget.product_detail_name,),
               ),
             ],
           ),

           Row(
             children: [
               Padding(
                 padding: EdgeInsets.fromLTRB(12.0, 5.0, 5.0, 5.0),
                 child: Text("product brand", style: TextStyle(color: Colors.grey,),),
               ),
               Padding(
                 padding: EdgeInsets.all(5.0),
                 child: Text(widget.product_detail_name,),
               ),
             ],
           ),

           Row(
             children: [
               Padding(
                 padding: EdgeInsets.fromLTRB(12.0, 5.0, 5.0, 5.0),
                 child: Text("product condition", style: TextStyle(color: Colors.grey,),),
               ),
               Padding(
                 padding: EdgeInsets.all(5.0),
                 child: Text(widget.product_detail_name,),
               ),
             ],
           ),

           Padding(
             padding: EdgeInsets.all(8.0),
             child: Text("Similar products"),
           ),

           // Simalar Products Section
           /*
           Container(
             height: 360.0,
           ),
           */
           
        ],
      ),
    );
  }
}

class Similar_products extends StatefulWidget {
  @override
  _Similar_productsState createState() => _Similar_productsState();
}

class _Similar_productsState extends State<Similar_products> {

  var product_list = [
    {
      "name": "Blazer",
      "picture": "resource/images/slider/1.jpg",
      "old_price": 120,
      "price": 85
    },
    {
      "name": "Dress",
      "picture": "resource/images/slider/2.jpg",
      "old_price": 120,
      "price": 100
    },
    {
      "name": "Shoes",
      "picture": "resource/images/slider/3.jpg",
      "old_price": 200,
      "price": 185
    },
    {
      "name": "New",
      "picture": "resource/images/slider/4.jpg",
      "old_price": 120,
      "price": 85
    },
  ];

  @override
  Widget build(BuildContext context) {
    return ;
  }
}